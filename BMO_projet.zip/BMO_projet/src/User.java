import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("08fa687c-8fc5-4342-92d6-c6777978c803")
public @interface User  {
    @objid ("a133111f-4c96-4d52-9f56-6186345b0082")
    int idUser();

    @objid ("822ea284-6127-40d3-9fdb-cc4c82d49e5d")
    String Attribute();

}
